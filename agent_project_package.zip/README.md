
# Agent-Based Communication System with SPADE and ejabberd

## 📌 Project Summary

This project demonstrates a multi-agent system using SPADE (Smart Python Agent Development Environment) that communicates via an ejabberd XMPP server. It includes three core agents:

- **UserAgent**: Provides an interface for user input.
- **DataValidationAgent**: Validates the user data and ensures correctness.
- **StorageAgent**: Receives validated data and stores it.

## 🧭 High-Level Communication Overview

This diagram provides a visual overview of how agents interact with each other through the ejabberd XMPP server.

![High-Level Agent-Ejabberd Communication](./docs/images/agent_ejabberd_overview.png)

## 🔁 Detailed Communication Flow

The following diagram shows the detailed message-passing steps between agents in your system:

![Detailed Flow of User → Validation → Storage](./docs/images/detailed_flow.png)

## 👥 Agents Overview

### UserAgent
- Role: Accepts input from the user (GUI/console).
- Sends input to the `DataValidationAgent`.

### DataValidationAgent
- Role: Validates input data.
- If valid, forwards it to `StorageAgent`. Otherwise, responds with an error.

### StorageAgent
- Role: Stores the validated data into a storage backend or log.

## 📡 Communication Flow

1. **UserAgent** sends input data to `DataValidationAgent`.
2. `DataValidationAgent` checks the data:
   - If valid → sends to `StorageAgent`
   - If invalid → replies to `UserAgent` with an error
3. `StorageAgent` stores the data and optionally sends an acknowledgment.

## ⚙️ Technologies

- SPADE 4.0.0
- ejabberd (XMPP server)
- Python 3.12
- Optional GUI via `tkinter`

## 📁 Structure

```
project_package/
├── README.md
└── docs/
    └── images/
        ├── agent_ejabberd_overview.png
        └── detailed_flow.png
```

